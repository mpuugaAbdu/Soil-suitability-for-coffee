# CoffeeSoilESP32

Inputs, in order:
1. pH
2. Nitrogen (%)
3. Phosphorus (mg/kg)
4. Potassium (meq/100g)

Install ArduTFLite (and its Chirale_TensorFlowLite dependency) in Arduino IDE.

IMPORTANT: many RS485 NPK sensors report N, P and K in mg/kg. This model currently expects N in %, P in mg/kg and K in meq/100g. Verify and convert your sensor units before inference.

The current Arabica/Robusta labels are proxy labels. Add measured altitude and temperature before treating this as a field-ready agronomic classifier.
