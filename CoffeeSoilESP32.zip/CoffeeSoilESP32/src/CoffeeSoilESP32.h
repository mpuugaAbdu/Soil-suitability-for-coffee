#pragma once
#include <Arduino.h>
enum CoffeeSuitabilityClass { ROBUSTA_SUITABLE=0, ARABICA_SUITABLE=1, NOT_SUITABLE=2, PREDICTION_ERROR=-1 };
struct CoffeePrediction { CoffeeSuitabilityClass classId; const char* label; float confidence; float probabilities[3]; };
class CoffeeSoilESP32 {
public:
  bool begin();
  CoffeePrediction predict(float pH, float nitrogenPercent, float phosphorusMgKg, float potassiumMeq100g);
private:
  bool ready_ = false;
};
