#include "CoffeeSoilESP32.h"
#include "coffee_soil_model.h"
#include <ArduTFLite.h>
static constexpr int NIN=4, NCLASS=3;
static constexpr int TENSOR_ARENA_SIZE=16*1024;
static byte tensorArena[TENSOR_ARENA_SIZE];
static const float MEAN[NIN]=5.571998632f, 0.179093197f, 72.193816319f, 0.901721769f;
static const float SCALE[NIN]=0.622922504f, 0.073465956f, 63.993692295f, 0.486193087f;
static const char* NAMES[NCLASS]={"Suitable for Robusta","Suitable for Arabica","Not Suitable"};

bool CoffeeSoilESP32::begin() {
  ready_ = modelInit(coffee_soil_model, tensorArena, TENSOR_ARENA_SIZE);
  return ready_;
}

CoffeePrediction CoffeeSoilESP32::predict(float ph,float n,float p,float k) {
  CoffeePrediction r;
  r.classId=PREDICTION_ERROR; r.label="Prediction error"; r.confidence=0.0f;
  for(int i=0;i<NCLASS;i++) r.probabilities[i]=0.0f;
  if(!ready_) return r;
  float raw[NIN]={ph,n,p,k};
  for(int i=0;i<NIN;i++)
    if(!modelSetInput((raw[i]-MEAN[i])/SCALE[i],i)) return r;
  if(!modelRunInference()) return r;
  int best=0; float bestP=-1.0f;
  for(int i=0;i<NCLASS;i++) {
    float q=modelGetOutput(i); r.probabilities[i]=q;
    if(q>bestP){bestP=q;best=i;}
  }
  r.classId=(CoffeeSuitabilityClass)best;
  r.label=NAMES[best];
  r.confidence=bestP;
  return r;
}
